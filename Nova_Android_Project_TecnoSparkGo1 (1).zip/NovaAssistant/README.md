# Nova - Native Android AI Assistant for TECNO Spark Go 1

Designed specifically for **TECNO Spark Go 1** running **Android 14 (Go / HiOS)** with **4 GB RAM** (Unisoc T606 Octa-core processor).

---

## 🌟 Key Features

1. **Native Jetpack Compose UI**: Fast, responsive, 120Hz smooth animations optimized for the 6.67" HD+ screen.
2. **Respectful Bengali Persona**: Always addresses the user respectfully as **“আপনি”** (never “তুমি” or “তুই”).
3. **Multilingual & Regional Bangla Support**:
   - Standard Bangla (শুদ্ধ বাংলা)
   - Dhakaiya (ঢাকাইয়া)
   - Chittagonian (চাটগাঁইয়া)
   - Sylheti (সিলেটি)
   - Banglish (Mixed Bangla-English)
   - Standard English
4. **Voice Recognition & Speech Control**:
   - Real Android `SpeechRecognizer` with `bn-BD` and `en-US` locales.
   - Real `TextToSpeech` voice feedback.
   - Dedicated **Stop-Speaking** button to instantly silence speech output.
5. **Multimodal Visual Results**: Displays generated images inline when requested.
6. **Ultra-Lightweight Memory Optimization**:
   - Designed for 4GB RAM phones: R8 full-mode shrinking, 50MB cached image buffer, lazy-loaded lists.
7. **Security Guarantee**:
   - Zero API keys in client source code. All requests flow through a secure backend proxy.
   - Minimal permissions: only `RECORD_AUDIO` and `INTERNET`.

---

## 🛠️ Requirements to Build

- **Android Studio**: Hedgehog (2023.1.1) or newer (Iguana, Jellyfish, Koala).
- **JDK**: Java 17.
- **Android SDK**: API 34 (Android 14).
- **Device**: TECNO Spark Go 1 (or any Android 8.0+ device / emulator).

---

## 🚀 How to Build & Install APK

### Method 1: Build in Android Studio
1. Unzip the downloaded `Nova_Android_Project.zip`.
2. Open Android Studio -> Click **Open** -> Select the unzipped folder.
3. Wait for Gradle Sync to complete.
4. Plug in your **TECNO Spark Go 1** via USB cable.
   - On phone: Go to **Settings** > **My Phone** > Tap **Build Number** 7 times to enable Developer Options.
   - Go to **System** > **Developer Options** > Turn on **USB Debugging**.
5. Select your device from the top toolbar dropdown in Android Studio.
6. Click **Run (Shift + F10)** to install and launch directly on your TECNO Spark Go 1!

### Method 2: Build APK via Terminal Command Line

```bash
# Linux / macOS
chmod +x gradlew
./gradlew assembleDebug

# Windows PowerShell / CMD
gradlew.bat assembleDebug
```

The generated APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

### Method 3: Install APK using ADB

```bash
# Check device is detected
adb devices

# Install APK to TECNO Spark Go 1
adb install -r app/build/outputs/apk/debug/app-debug.apk
```
