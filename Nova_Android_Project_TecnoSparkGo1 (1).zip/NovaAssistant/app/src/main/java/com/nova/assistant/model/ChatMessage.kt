package com.nova.assistant.model

import java.util.UUID

enum class MessageRole {
    USER,
    NOVA
}

enum class DialectOption(val id: String, val displayName: String, val sampleText: String) {
    STANDARD("standard", "শুদ্ধ বাংলা (Standard Bangla)", "আপনি কেমন আছেন? আমি কীভাবে সাহায্য করতে পারি?"),
    DHAKAIYA("dhakaiya", "ঢাকাইয়া (Dhakaiya)", "কী খবর মামা, আপনি কেমন আছেন? কী কাম করন লাগব কন?"),
    CHITTAGONIAN("chittagonian", "চাটগাঁইয়া (Chittagonian)", "অনারা গম আছন নি? আঁই ক্যানে সাহায্য গরিত পারি?"),
    SYLHETI("sylheti", "সিলেটি (Sylheti)", "আপনার ভালা নি? আমি আপনার লাগি কী করতাম পারি?"),
    BANGLISH("banglish", "বাংলিশ (Banglish)", "Apni kemon achen? Ami apnake kivabe help korte pari?"),
    ENGLISH("english", "English", "How may I respectfully assist you today?")
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val content: String,
    val role: MessageRole,
    val timestamp: Long = System.currentTimeMillis(),
    val imageUrl: String? = null,
    val isSpeaking: Boolean = false,
    val isError: Boolean = false
)

data class NovaSettings(
    val dialect: DialectOption = DialectOption.STANDARD,
    val autoSpeakResponses: Boolean = false,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val lowRamOptimization: Boolean = true, // Default ON for TECNO Spark Go 1
    val hasMicPermission: Boolean = false
)
