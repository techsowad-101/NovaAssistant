package com.nova.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nova.assistant.model.DialectOption
import com.nova.assistant.viewmodel.NovaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NovaSettingsScreen(
    viewModel: NovaViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "সেটিংস ও পছন্দসমূহ") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "পেছনে যান"
                        )
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Language & Dialect Selection
            Text(
                text = "ভাষা ও আঞ্চলিক রূপ (Language & Dialects)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    DialectOption.values().forEach { option ->
                        val isSelected = uiState.settings.dialect == option
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.updateDialect(option) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { viewModel.updateDialect(option) }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = option.displayName,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "উদাহরণ: ${option.sampleText}",
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            }
                        }
                    }
                }
            }

            // 2. Respectful Address Enforcement
            Text(
                text = "সম্মানসূচক সম্বোধন (Honorifics)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "সর্বদা “আপনি” সম্বোধন",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "নোভা আপনাকে সর্বদা সর্বোচ্চ শ্রদ্ধার সাথে “আপনি” সম্বোধনে উত্তর দেবে।",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Switch(
                        checked = true,
                        onCheckedChange = null,
                        enabled = false // Locked as fundamental core persona requirement
                    )
                }
            }

            // 3. Voice & Speech Settings
            Text(
                text = "ভয়েস ও অডিও (Voice & Audio)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "উত্তরের সাথে স্বয়ংক্রিয় পাঠ (Auto-Speak)", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(text = "নোভা প্রতিটি উত্তরের পর তা মুখে বলবে", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = uiState.settings.autoSpeakResponses,
                            onCheckedChange = { viewModel.updateAutoSpeak(it) }
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "কথা বলার গতি: ${String.format("%.1f", uiState.settings.speechRate)}x", fontSize = 13.sp)
                    Slider(
                        value = uiState.settings.speechRate,
                        onValueChange = { viewModel.updateSpeechRate(it) },
                        valueRange = 0.7f..1.5f,
                        steps = 7
                    )
                }
            }

            // 4. Android 14 Permissions Status
            Text(
                text = "অ্যাপ পারমিশন (Android 14 Permissions)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(text = "মাইক্রোফোন (RECORD_AUDIO)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(
                                text = if (uiState.settings.hasMicPermission) "অনুমোদিত (Granted)" else "অনুমতি দেওয়া হয়নি",
                                fontSize = 12.sp,
                                color = if (uiState.settings.hasMicPermission) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                            )
                        }
                        Icon(
                            imageVector = if (uiState.settings.hasMicPermission) Icons.Default.CheckCircle else Icons.Default.Cancel,
                            contentDescription = null,
                            tint = if (uiState.settings.hasMicPermission) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "গোপনীয়তার নিশ্চয়তা: নোভা কেবল কথা বলার সময় মাইক্রোফোন সক্রিয় করে। কোনো অপ্রয়োজনীয় পারমিশন (যেমন ক্যামেরা বা কন্টাক্টস) চাওয়া হয় না।",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }

            // 5. Device & Memory Optimization Info (TECNO Spark Go 1)
            Text(
                text = "ডিভাইস অপ্টিমাইজেশন (TECNO Spark Go 1)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = "৪ জিবি র্যাম অপ্টিমাইজেশন মোড", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(text = "রিসোর্স কনজাম্পশন কমিয়ে গতি বাড়ায়", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(
                            checked = uiState.settings.lowRamOptimization,
                            onCheckedChange = { viewModel.updateLowRamOptimization(it) }
                        )
                    }
                    Divider(modifier = Modifier.padding(vertical = 10.dp))
                    Text(text = "• চিপসেট: Unisoc T606 (Octa-Core)", fontSize = 12.sp)
                    Text(text = "• ওএস: Android 14 (Go Edition / HiOS 14)", fontSize = 12.sp)
                    Text(text = "• ব্যাকএন্ড প্রক্সি: Gemini 3.8 Flash (সুরক্ষিত API কী)", fontSize = 12.sp)
                }
            }
        }
    }
}
