package com.nova.assistant

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

/**
 * Custom Application class tailored for TECNO Spark Go 1 (4GB RAM)
 * Constrains memory cache size to prevent OutOfMemory on Android 14 Go
 */
class NovaApplication : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    // Reserve max 15% of app memory for image caching
                    .maxSizePercent(0.15)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("nova_image_cache"))
                    .maxSizeBytes(50L * 1024L * 1024L) // 50MB disk cache
                    .build()
            }
            .respectCacheHeaders(false)
            .build()
    }
}
