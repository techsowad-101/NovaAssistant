package com.nova.assistant.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.nova.assistant.audio.NovaSpeechManager
import com.nova.assistant.audio.VoiceState
import com.nova.assistant.model.ChatMessage
import com.nova.assistant.model.DialectOption
import com.nova.assistant.model.MessageRole
import com.nova.assistant.model.NovaSettings
import com.nova.assistant.network.NovaApiService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class NovaUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isSending: Boolean = false,
    val inputText: String = "",
    val settings: NovaSettings = NovaSettings(),
    val voiceState: VoiceState = VoiceState.Idle,
    val errorMessage: String? = null
)

class NovaViewModel(application: Application) : AndroidViewModel(application) {

    private val apiService = NovaApiService()
    private val speechManager = NovaSpeechManager(application) { recognizedText ->
        sendMessage(recognizedText)
    }

    private val _uiState = MutableStateFlow(NovaUiState())
    val uiState: StateFlow<NovaUiState> = _uiState.asStateFlow()

    init {
        // Observe speech manager state
        viewModelScope.launch {
            speechManager.voiceState.collect { vState ->
                _uiState.update { it.copy(voiceState = vState) }
            }
        }

        // Initial warm, respectful greeting addressing the user as “আপনি”
        addInitialGreeting()
    }

    private fun addInitialGreeting() {
        val initialGreeting = ChatMessage(
            content = "নমস্কার / আসসালামু আলাইকুম! আমি নোভা, আপনার স্মার্টফোন সহায়ক। আজ আপনাকে কীভাবে সাহায্য করতে পারি?",
            role = MessageRole.NOVA
        )
        _uiState.update { it.copy(messages = listOf(initialGreeting)) }
    }

    fun onInputTextChanged(text: String) {
        _uiState.update { it.copy(inputText = text) }
    }

    fun sendMessage(textOverride: String? = null) {
        val textToSend = (textOverride ?: _uiState.value.inputText).trim()
        if (textToSend.isBlank() || _uiState.value.isSending) return

        val userMessage = ChatMessage(
            content = textToSend,
            role = MessageRole.USER
        )

        val currentMessages = _uiState.value.messages + userMessage
        _uiState.update {
            it.copy(
                messages = currentMessages,
                inputText = "",
                isSending = true,
                errorMessage = null
            )
        }

        viewModelScope.launch {
            val dialect = _uiState.value.settings.dialect.id
            val result = apiService.sendChatMessage(
                userPrompt = textToSend,
                history = currentMessages,
                dialectId = dialect
            )

            result.onSuccess { response ->
                val novaMessage = ChatMessage(
                    content = response.text,
                    role = MessageRole.NOVA,
                    imageUrl = response.imageUrl
                )

                _uiState.update {
                    it.copy(
                        messages = it.messages + novaMessage,
                        isSending = false
                    )
                }

                // If auto-speak is enabled, speak the answer
                if (_uiState.value.settings.autoSpeakResponses) {
                    speechManager.speak(
                        text = response.text,
                        rate = _uiState.value.settings.speechRate,
                        pitch = _uiState.value.settings.speechPitch
                    )
                }
            }.onFailure { error ->
                val errorMessage = ChatMessage(
                    content = "দুঃখিত, সংযোগে সমস্যা হয়েছে। আপনি কি অনুগ্রহ করে পুনরায় চেষ্টা করবেন? (${error.localizedMessage ?: "অজানা ত্রুটি"})",
                    role = MessageRole.NOVA,
                    isError = true
                )
                _uiState.update {
                    it.copy(
                        messages = it.messages + errorMessage,
                        isSending = false,
                        errorMessage = error.localizedMessage
                    )
                }
            }
        }
    }

    fun toggleMicrophone(isBanglaMode: Boolean = true) {
        if (_uiState.value.voiceState is VoiceState.Listening) {
            speechManager.stopListening()
        } else {
            speechManager.startListening(isBanglaMode)
        }
    }

    fun stopSpeaking() {
        speechManager.stopSpeaking()
    }

    fun speakMessage(message: ChatMessage) {
        speechManager.speak(
            text = message.content,
            rate = _uiState.value.settings.speechRate,
            pitch = _uiState.value.settings.speechPitch
        )
    }

    fun clearHistory() {
        stopSpeaking()
        speechManager.stopListening()
        addInitialGreeting()
    }

    fun updateDialect(dialect: DialectOption) {
        _uiState.update { it.copy(settings = it.settings.copy(dialect = dialect)) }
    }

    fun updateAutoSpeak(enabled: Boolean) {
        _uiState.update { it.copy(settings = it.settings.copy(autoSpeakResponses = enabled)) }
    }

    fun updateSpeechRate(rate: Float) {
        _uiState.update { it.copy(settings = it.settings.copy(speechRate = rate)) }
    }

    fun updateLowRamOptimization(enabled: Boolean) {
        _uiState.update { it.copy(settings = it.settings.copy(lowRamOptimization = enabled)) }
    }

    fun onMicrophonePermissionResult(granted: Boolean) {
        _uiState.update { it.copy(settings = it.settings.copy(hasMicPermission = granted)) }
    }

    fun cleanup() {
        speechManager.cleanup()
    }

    override fun onCleared() {
        super.onCleared()
        cleanup()
    }
}
