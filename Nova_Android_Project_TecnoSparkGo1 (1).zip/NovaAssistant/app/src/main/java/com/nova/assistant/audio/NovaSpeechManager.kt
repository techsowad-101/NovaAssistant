package com.nova.assistant.audio

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

sealed class VoiceState {
    object Idle : VoiceState()
    object Listening : VoiceState()
    data class Recognized(val text: String) : VoiceState()
    data class Speaking(val text: String) : VoiceState()
    data class Error(val message: String) : VoiceState()
}

/**
 * Manages Speech-to-Text (SpeechRecognizer) and Text-to-Speech (TTS)
 * Includes Bengali (bn-BD) locale matching and STOP SPEAKING control.
 */
class NovaSpeechManager(
    private val context: Context,
    private val onTextRecognized: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var isTtsReady = false

    private val _voiceState = MutableStateFlow<VoiceState>(VoiceState.Idle)
    val voiceState: StateFlow<VoiceState> = _voiceState

    init {
        initTts()
    }

    private fun initTts() {
        textToSpeech = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                // Try Bengali first, then English fallback
                val bengaliLocale = Locale("bn", "BD")
                val langResult = textToSpeech?.setLanguage(bengaliLocale)
                if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    textToSpeech?.setLanguage(Locale.US)
                }
                isTtsReady = true

                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        _voiceState.value = VoiceState.Idle
                    }
                    override fun onError(utteranceId: String?) {
                        _voiceState.value = VoiceState.Idle
                    }
                })
            }
        }
    }

    /**
     * Start speech recognition for Bengali or English
     */
    fun startListening(isBanglaMode: Boolean = true) {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _voiceState.value = VoiceState.Error("আপনার ডিভাইসে স্পিচ রিকগনিশন সেবা পাওয়া যায়নি")
            return
        }

        stopSpeaking()
        stopListening()

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _voiceState.value = VoiceState.Listening
                }

                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    _voiceState.value = VoiceState.Idle
                }

                override fun onError(error: Int) {
                    val errorMsg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "কোনো কথা শনাক্ত করা যায়নি। আবার বলুন।"
                        SpeechRecognizer.ERROR_NETWORK -> "নেটওয়ার্ক সংযোগ ত্রুটি"
                        SpeechRecognizer.ERROR_AUDIO -> "অডিও রেকর্ডিং ত্রুটি"
                        else -> "মাইক্রোফোন ত্রুটি (${error})"
                    }
                    _voiceState.value = VoiceState.Error(errorMsg)
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val resultText = matches?.firstOrNull().orEmpty()
                    if (resultText.isNotBlank()) {
                        _voiceState.value = VoiceState.Recognized(resultText)
                        onTextRecognized(resultText)
                    } else {
                        _voiceState.value = VoiceState.Idle
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (isBanglaMode) "bn-BD" else "en-US")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, if (isBanglaMode) "bn-BD" else "en-US")
            putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        speechRecognizer?.startListening(intent)
        _voiceState.value = VoiceState.Listening
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {}
        if (_voiceState.value is VoiceState.Listening) {
            _voiceState.value = VoiceState.Idle
        }
    }

    /**
     * Stop speaking immediately (Requirement: Stop-speaking button)
     */
    fun stopSpeaking() {
        try {
            if (textToSpeech?.isSpeaking == true) {
                textToSpeech?.stop()
            }
        } catch (_: Exception) {}
        _voiceState.value = VoiceState.Idle
    }

    fun speak(text: String, rate: Float = 1.0f, pitch: Float = 1.0f) {
        if (!isTtsReady || text.isBlank()) return
        stopSpeaking()

        textToSpeech?.setSpeechRate(rate)
        textToSpeech?.setPitch(pitch)

        // Remove markdown symbols for cleaner TTS narration
        val cleanText = text
            .replace(Regex("[*#_\u0060~]"), "")
            .replace(Regex("!\[.*?\]\(.*?\)"), "")
            .trim()

        _voiceState.value = VoiceState.Speaking(cleanText)
        textToSpeech?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "nova_tts_${System.currentTimeMillis()}")
    }

    fun cleanup() {
        stopListening()
        stopSpeaking()
        textToSpeech?.shutdown()
        textToSpeech = null
    }
}
