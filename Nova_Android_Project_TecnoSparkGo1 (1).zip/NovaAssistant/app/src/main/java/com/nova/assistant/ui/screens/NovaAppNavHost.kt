package com.nova.assistant.ui.screens

import androidx.compose.runtime.*
import com.nova.assistant.viewmodel.NovaViewModel

enum class NovaScreen {
    CHAT,
    SETTINGS
}

@Composable
fun NovaAppNavHost(
    viewModel: NovaViewModel,
    onRequestMicPermission: () -> Unit
) {
    var currentScreen by remember { mutableStateOf(NovaScreen.CHAT) }

    when (currentScreen) {
        NovaScreen.CHAT -> {
            NovaChatScreen(
                viewModel = viewModel,
                onRequestMicPermission = onRequestMicPermission,
                onNavigateSettings = { currentScreen = NovaScreen.SETTINGS }
            )
        }
        NovaScreen.SETTINGS -> {
            NovaSettingsScreen(
                viewModel = viewModel,
                onNavigateBack = { currentScreen = NovaScreen.CHAT }
            )
        }
    }
}
