package com.nova.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = NovaTeal,
    onPrimary = Color.White,
    primaryContainer = NovaTealDark,
    onPrimaryContainer = Color.White,
    background = NovaBackgroundDark,
    surface = NovaSurfaceDark,
    surfaceVariant = NovaSurfaceVariantDark,
    onBackground = NovaTextPrimary,
    onSurface = NovaTextPrimary,
    onSurfaceVariant = NovaTextSecondary,
    error = Color(0xFFEF4444),
    errorContainer = Color(0xFF7F1D1D),
    onErrorContainer = Color(0xFFFCA5A5)
)

@Composable
fun NovaAssistantTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
