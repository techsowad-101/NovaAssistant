package com.nova.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val NovaTeal = Color(0xFF0D9488)
val NovaTealDark = Color(0xFF0F766E)
val NovaTealLight = Color(0xFF2DD4BF)

val NovaBackgroundDark = Color(0xFF0A0F1D)
val NovaSurfaceDark = Color(0xFF131B2E)
val NovaSurfaceVariantDark = Color(0xFF1E293B)

val NovaTextPrimary = Color(0xFFF8FAFC)
val NovaTextSecondary = Color(0xFF94A3B8)
