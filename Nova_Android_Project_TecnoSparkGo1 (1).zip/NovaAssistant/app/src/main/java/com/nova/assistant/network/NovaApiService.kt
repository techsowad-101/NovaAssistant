package com.nova.assistant.network

import com.nova.assistant.BuildConfig
import com.nova.assistant.model.ChatMessage
import com.nova.assistant.model.MessageRole
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Secure Network Client for Nova Assistant
 * Communicates with server-side proxy which holds the Gemini API Key.
 * NO API KEYS ARE STORED IN THE ANDROID CLIENT!
 */
class NovaApiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun sendChatMessage(
        userPrompt: String,
        history: List<ChatMessage>,
        dialectId: String
    ): Result<NovaApiResponse> = withContext(Dispatchers.IO) {
        try {
            val endpoint = "${BuildConfig.BASE_BACKEND_URL}/api/chat"

            val jsonBody = JSONObject().apply {
                put("userPrompt", userPrompt)
                put("dialect", dialectId)
                put("autoDetectImage", true)

                val messagesArray = JSONArray()
                // Take only last 6 messages to save bandwidth and memory on 4GB device
                val recentHistory = history.takeLast(6)
                for (msg in recentHistory) {
                    val msgObj = JSONObject().apply {
                        put("role", if (msg.role == MessageRole.USER) "user" else "model")
                        put("content", msg.content)
                    }
                    messagesArray.put(msgObj)
                }
                put("messages", messagesArray)
            }

            val request = Request.Builder()
                .url(endpoint)
                .post(jsonBody.toString().toRequestBody(jsonMediaType))
                .header("User-Agent", "NovaAssistant-Android14-SparkGo1")
                .header("Accept", "application/json")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        Exception("সার্ভার ত্রুটি: ${response.code} ${response.message}")
                    )
                }

                val responseString = response.body?.string().orEmpty()
                val jsonRes = JSONObject(responseString)

                val replyText = jsonRes.optString(
                    "text",
                    "আপনার অনুরোধটি সম্পন্ন হয়েছে।"
                )
                val imageUrl = if (jsonRes.has("imageUrl") && !jsonRes.isNull("imageUrl")) {
                    jsonRes.getString("imageUrl")
                } else null

                Result.success(
                    NovaApiResponse(
                        text = replyText,
                        imageUrl = imageUrl
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

data class NovaApiResponse(
    val text: String,
    val imageUrl: String?
)
