# R8 Proguard Rules for Nova Assistant (TECNO Spark Go 1 4GB RAM)
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable

# Preserve KotlinX Serialization data classes
-keepclassmembers class * {
    *** Companion;
}
-keepclasseswithmembers class * {
    kotlinx.serialization.KSerializer serializer(...);
}

# Preserve OkHttp3 & Coil
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn coil.**
